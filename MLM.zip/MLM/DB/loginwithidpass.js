const { v4: uuidv4 } = require("uuid");
const mongoose = require('mongoose');
require('../DB/mongodb')
const LoginSchema = require('../DB/schemas/signupShema')
const express = require('express');
const router = express.Router();
const {setUser} = require('../config/auth')

const cookieParser = require('cookie-parser');


router.use(express.json())
router.use(express.urlencoded({extended:false}))
router.use(cookieParser());

router.post("/login", async (req,res) => {
    const { phoneNumber,password } = req.body;
    let data = await LoginSchema.findOne({ phoneNumber,password });
    // console.log(data);

    if(data){
        const token = setUser(data);
        res.cookie("uid", token);
        res.redirect('/home')
    }else{
        const dataOfSending = `<!DOCTYPE html>
        <html lang="en">
        <head>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
                integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
                crossorigin="anonymous" referrerpolicy="no-referrer" />
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,500;0,600;0,800;1,900&display=swap"
                rel="stylesheet">
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Error</title>
            <style>
                .centerOne{
                    width: 100%;
                    height: 200px;
                    display: flex;
            flex-wrap: wrap;
            justify-content: center;
                }
                .centerOne i{
                    color: red;
                    font-size: 120px;
                }
            </style>
        </head>
        <body>
            <div class="centerOne">
        <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h1 style="text-align: center;font-family: 'Poppins', sans-serif;">Please check Your PhoneNumber and Password</h1>
        </body>
        </html>`
        res.send(dataOfSending);

    }

})





module.exports = router;