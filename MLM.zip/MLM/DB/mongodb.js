const mongodb = require('mongoose');
require('dotenv').config();

const database = mongodb.connect(process.env.DATABASE).then(()=>{
console.log("connected DB");
});


module.exports = database;
